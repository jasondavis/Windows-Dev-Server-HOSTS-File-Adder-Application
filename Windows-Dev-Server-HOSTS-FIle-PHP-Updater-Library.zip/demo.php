<?php








// Add record to Windows HOSTS file
// HOSTS file C:\Windows\System32\drivers\etc\HOSTS
@exec('set-dev-server-domain-hosts-file-entry.exe dev-project.dev');



